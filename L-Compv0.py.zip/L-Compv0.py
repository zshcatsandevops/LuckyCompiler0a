import subprocess
import sys

def compile_c_file(file_name):
    """Compiles a C file to an object file."""
    command = ["gcc", "-c", file_name]
    output = subprocess.run(command, capture_output=True)
    if output.returncode != 0:
        raise RuntimeError(output.stderr)

    return output.stdout

def main():
    """The main function."""
    if len(sys.argv) != 2:
        print("Usage: luckycompiler <c_file_name>")
        sys.exit(1)

    file_name = sys.argv[1]
    object_file = compile_c_file(file_name)

    print(f"Wrote object file {object_file}")

if __name__ == "__main__":
    main()
